/*
 *  Copyright (C) 2017 - This file is part of libecc project
 *
 *  Authors:
 *      Ryad BENADJILA <ryadbenadjila@gmail.com>
 *      Arnaud EBALARD <arnaud.ebalard@ssi.gouv.fr>
 *      Jean-Pierre FLORI <jean-pierre.flori@ssi.gouv.fr>
 *
 *  Contributors:
 *      Nicolas VIVET <nicolas.vivet@ssi.gouv.fr>
 *      Karim KHALFALLAH <karim.khalfallah@ssi.gouv.fr>
 *
 *  This software is licensed under a dual BSD and GPL v2 license.
 *  See LICENSE file at the root folder of the project.
 */
#ifndef __PACKED_PT_H__
#define __PACKED_PT_H__

#include "../nn/nn_mul.h"
#include "../fp/fp.h"
#include "../fp/fp_mul.h"
#include "../fp/fp_mul_redc1.h"
#include "ec_shortw.h"
#include "prj_pt.h"
#include "ec_params.h"

typedef struct {
	fp x;
	uint8_t sign;
	ec_shortw_crv_src_t crv;
	word_t magic;
} packed_pt;

typedef packed_pt *packed_pt_t;
typedef const packed_pt *packed_pt_src_t;



ATTRIBUTE_WARN_UNUSED_RET int packed_pt_check_initialized(packed_pt_src_t in);
ATTRIBUTE_WARN_UNUSED_RET int packed_pt_init(packed_pt_t in, ec_shortw_crv_src_t curve);
ATTRIBUTE_WARN_UNUSED_RET int packed_pt_init_from_coords(packed_pt_t in, ec_shortw_crv_src_t curve, fp_src_t xcoord, uint8_t sign);
ATTRIBUTE_WARN_UNUSED_RET int packed_pt_unpack(prj_pt_t out, packed_pt_src_t in);
ATTRIBUTE_WARN_UNUSED_RET int packed_pt_pack(packed_pt_t out, prj_pt_src_t in);

ATTRIBUTE_WARN_UNUSED_RET int packed_win_unpack(win_t win, const ec_str_params *in_str_params, ec_shortw_crv_src_t curve );

ATTRIBUTE_WARN_UNUSED_RET int packed_pt_is_on_curve(packed_pt_src_t pt, int *on_curve);
ATTRIBUTE_WARN_UNUSED_RET int ec_shortw_packed_copy(packed_pt_t out, packed_pt_src_t in);
ATTRIBUTE_WARN_UNUSED_RET int ec_shortw_packed_cmp(packed_pt_src_t in1, packed_pt_src_t in2, int *cmp);
ATTRIBUTE_WARN_UNUSED_RET int ec_shortw_packed_eq_or_opp(packed_pt_src_t in1, packed_pt_src_t in2, int *packed_is_eq_or_opp);
ATTRIBUTE_WARN_UNUSED_RET int packed_pt_import_from_buf(packed_pt_t pt, const u8 *pt_buf, u16 pt_buf_len, ec_shortw_crv_src_t crv);
ATTRIBUTE_WARN_UNUSED_RET int packed_pt_export_to_buf(packed_pt_src_t pt, u8 *pt_buf, u16 pt_buf_len);


#endif /* __PACKED_PT_H__ */
