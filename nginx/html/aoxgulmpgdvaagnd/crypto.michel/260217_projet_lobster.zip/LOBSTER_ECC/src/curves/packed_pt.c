/*
 *  Copyright (C) 2017 - This file is part of libecc project
 *
 *  Authors:
 *      Ryad BENADJILA <ryadbenadjila@gmail.com>
 *      Arnaud EBALARD <arnaud.ebalard@ssi.gouv.fr>
 *      Jean-Pierre FLORI <jean-pierre.flori@ssi.gouv.fr>
 *
 *  Contributors:
 *      Nicolas VIVET <nicolas.vivet@ssi.gouv.fr>
 *      Karim KHALFALLAH <karim.khalfallah@ssi.gouv.fr>
 *
 *  This software is licensed under a dual BSD and GPL v2 license.
 *  See LICENSE file at the root folder of the project.
 */

# include "../utils/dbg_sig.h"
#include "packed_pt.h"

#define PACKED_PT_MAGIC ((word_t)(0x6c6f627374657221ULL))


int packed_pt_check_initialized(packed_pt_src_t in)
{
	int ret;

	MUST_HAVE(((in != NULL) && (in->magic == PACKED_PT_MAGIC)), ret, err);
	ret = ec_shortw_crv_check_initialized(in->crv);

err:
	return ret;
}


int packed_pt_init(packed_pt_t in, ec_shortw_crv_src_t curve)
{
	int ret;

	MUST_HAVE((in != NULL), ret, err);
	MUST_HAVE((curve != NULL), ret, err);

	ret = ec_shortw_crv_check_initialized(curve); EG(ret, err);
	ret = fp_init(&(in->x), curve->a.ctx); EG(ret, err);
	in->sign = 0;
	in->crv = curve;
	in->magic = PACKED_PT_MAGIC;

err:
	return ret;
}


int packed_pt_init_from_coords(packed_pt_t in,
			    ec_shortw_crv_src_t curve,
			    fp_src_t xcoord, uint8_t sign)
{
	int ret;

	MUST_HAVE(((sign == 2)||(sign == 3)), ret, err);
	ret = packed_pt_init(in, curve); EG(ret, err);
	ret = fp_copy(&(in->x), xcoord); EG(ret, err);
	in->sign=sign;

err:
	return ret;
}


void packed_pt_uninit(packed_pt_t in)
{
	if((in != NULL) && (in->magic == PACKED_PT_MAGIC) && (in->crv != NULL)){
		in->crv = NULL;
		in->magic = WORD(0);

		fp_uninit(&(in->x));
		in->sign = 0;
	}

	return;
}


int packed_pt_unpack(prj_pt_t out, packed_pt_src_t in)
{
	int ret, s, parity_check;
	fp y1, y2;
	fp_t y;
	nn two;
	nn parity;

	ret = packed_pt_check_initialized(in); EG(ret, err);
	ret = nn_init(&two, 0); EG(ret, err);
	ret = nn_init(&parity, 0); EG(ret, err);
	ret = nn_set_word_value(&two, WORD(2)); EG(ret, err);

	/* Compression is either 02 or 03 */
	MUST_HAVE(((in->sign == 0x02) || (in->sign == 0x03)), ret, err);

	ret =  prj_pt_init(out, in->crv);  EG(ret, err);

	/* Import our x coordinate */
	ret = fp_init(&y1, in->crv->a.ctx); EG(ret, err);
	ret = fp_init(&y2, in->crv->a.ctx); EG(ret, err);

	/* Compute the Weierstrass equation y^2 = x^3 + ax + b solutions */
	ret = aff_pt_y_from_x(&y2, &y1, &(in->x), in->crv); EG(ret, err);

	/* Choose the square root depending on the compression information */
	s = (in->sign - 2);

	ret = nn_mod(&parity, &y1.fp_val, &two); EG(ret, err);
	ret = nn_isone(&parity, &parity_check); EG(ret, err);
	y = (parity_check == s) ? &y1 : &y2;


	ret = fp_copy((&out->X), &in->x); EG(ret, err);
	ret = fp_copy((&out->Y), y); EG(ret, err);

	/* Z coordinate is set to 1 */
	ret = fp_init(&(out->Z), in->crv->a.ctx); EG(ret, err);
	ret = fp_one(&(out->Z)); EG(ret, err);

err:
	fp_uninit(&y1);
	fp_uninit(&y2);
	PTR_NULLIFY(y);

	return ret;
}


int packed_pt_pack(packed_pt_t out, prj_pt_src_t in) {
	
	int ret;
	int parity_val;
	nn two;
	nn parity;
	aff_pt in_aff;

	ret = prj_pt_check_initialized(in); EG(ret, err);

	ret = aff_pt_init(&in_aff, in->crv); EG(ret, err);
	ret = prj_pt_to_aff(&in_aff, in); EG(ret, err);


	ret = nn_init(&two, 0); EG(ret, err);
	ret = nn_init(&parity, 0); EG(ret, err);
	ret = nn_set_word_value(&two, WORD(2)); EG(ret, err);

	ret =  packed_pt_init(out, in->crv);  EG(ret, err);

	/* Import our x coordinate */
	ret = fp_copy((&out->x), &in_aff.x); EG(ret, err);


	/* Choose the square root depending on the compression information */

	ret = nn_mod(&parity, &in_aff.y.fp_val, &two); EG(ret, err);
	ret = nn_isone(&parity, &parity_val); EG(ret, err);
	out->sign = parity_val + 2;

err:
	aff_pt_uninit(&in_aff);
	nn_uninit(&parity);
	nn_uninit(&two);

	return ret;
}

int packed_pt_is_on_curve(packed_pt_src_t pt, int *on_curve)
{
	int ret;
	prj_pt proj;
	MUST_HAVE((on_curve != NULL), ret, err);

	ret = prj_pt_init(&proj, pt->crv); EG(ret, err);
	ret = packed_pt_check_initialized(pt); EG(ret, err);
	ret = packed_pt_unpack(&proj, pt); EG(ret, err);
	ret = prj_pt_is_on_curve(&proj, on_curve); EG(ret, err);
err:
	return ret;
}

int ec_shortw_packed_copy(packed_pt_t out, packed_pt_src_t in)
{
	int ret;

	ret = packed_pt_check_initialized(in); EG(ret, err);
	ret = packed_pt_init(out, in->crv); EG(ret, err);
	ret = fp_copy(&(out->x), &(in->x)); EG(ret, err);
	out->sign = in->sign;

err:
	return ret;
}

int ec_shortw_packed_cmp(packed_pt_src_t in1, packed_pt_src_t in2, int *cmp)
{
	int ret, cmp_x, cmp_y;

	MUST_HAVE((cmp != NULL), ret, err);

	ret = packed_pt_check_initialized(in1); EG(ret, err);
	ret = packed_pt_check_initialized(in2); EG(ret, err);

	MUST_HAVE((in1->crv == in2->crv), ret, err);

	ret = fp_cmp(&(in1->x), &(in2->x), &cmp_x); EG(ret, err);
	cmp_y = (in1->sign == in2->sign) ? 0 : 1;

	(*cmp) = (cmp_x | cmp_y);

err:
	return ret;
}

int ec_shortw_packed_eq_or_opp(packed_pt_src_t in1, packed_pt_src_t in2, int *packed_is_eq_or_opp)
{
	int ret, cmp;

	ret = packed_pt_check_initialized(in1); EG(ret, err);
	ret = packed_pt_check_initialized(in2); EG(ret, err);
	MUST_HAVE((in1->crv == in2->crv), ret, err);
	MUST_HAVE((packed_is_eq_or_opp != NULL), ret, err);

	MUST_HAVE(((in1->sign == 0x02) || (in1->sign == 0x03)), ret, err);
	MUST_HAVE(((in2->sign == 0x02) || (in2->sign == 0x03)), ret, err);

	ret = fp_cmp(&(in1->x), &(in2->x), &cmp); EG(ret, err);
	(*packed_is_eq_or_opp) = (cmp == 0);

err:
	return ret;
}


int packed_pt_import_from_buf(packed_pt_t pt, const u8 *pt_buf, u16 pt_buf_len, ec_shortw_crv_src_t crv)
{
	fp_ctx_src_t ctx;
	u16 coord_len;
	int ret, on_curve;

	MUST_HAVE((pt_buf != NULL), ret, err);
	MUST_HAVE((pt != NULL), ret, err);
	ret = ec_shortw_crv_check_initialized(crv); EG(ret, err);

	ctx = crv->a.ctx;
	coord_len = (u16)BYTECEIL(ctx->p_bitlen);

	MUST_HAVE((pt_buf_len == (coord_len + 1)), ret, err);

	ret = fp_init_from_buf(&(pt->x), ctx, pt_buf, coord_len); EG(ret, err);
	pt->sign = *((uint8_t *)(pt_buf + coord_len));


	/* Set the curve */
	pt->crv = crv;

	/* Mark the point as initialized */
	pt->magic = PACKED_PT_MAGIC;

	/*
	 * Check that the point is indeed on provided curve, uninitialize it
	 * if this is not the case.
	 */
	ret = packed_pt_is_on_curve(pt, &on_curve); EG(ret, err);

	if (!on_curve) {
		packed_pt_uninit(pt);
		ret = -1;
	} else {
		ret = 0;
	}

err:
	PTR_NULLIFY(ctx);

	return ret;
}

int packed_pt_export_to_buf(packed_pt_src_t pt, u8 *pt_buf, u16 pt_buf_len)
{
	u16 coord_len;
	int ret, on_curve;

	MUST_HAVE((pt_buf != NULL), ret, err);

	/* The point to be exported must be on the curve */
	ret = packed_pt_is_on_curve(pt, &on_curve); EG(ret, err);
	MUST_HAVE((on_curve), ret, err);

	/* buffer size must match p_len (size of x) + 1 (size of sign) */
	coord_len = (u16)BYTECEIL(pt->crv->a.ctx->p_bitlen);
	MUST_HAVE((pt_buf_len == (coord_len + 1)), ret, err);

	/* Export the two coordinates */
	ret = fp_export_to_buf(pt_buf, coord_len, &(pt->x)); EG(ret, err);
	*((uint8_t *)(pt_buf + coord_len)) = pt->sign;
err:
	return ret;
}


int packed_win_unpack(win_t win, const ec_str_params *in_str_params, ec_shortw_crv_src_t curve ) {

	int ret;
	int i;
	packed_pt pt;

	for (i=0; i<8; i++) {
		ret =  prj_pt_init(&win[i], curve);  EG(ret, err);
	}
	ret = prj_pt_zero(&win[0]); EG(ret, err);
	ret = packed_pt_init(&pt, curve); EG(ret, err);

	ret = packed_pt_import_from_buf(&pt, PARAM_BUF_PTR(in_str_params->G1), PARAM_BUF_LEN(in_str_params->G1), curve); EG(ret, err);
	ret = packed_pt_unpack(&win[1], &pt); EG(ret, err);
    
	ret = packed_pt_import_from_buf(&pt, PARAM_BUF_PTR(in_str_params->G2), PARAM_BUF_LEN(in_str_params->G2), curve); EG(ret, err);
	ret = packed_pt_unpack(&win[2], &pt); EG(ret, err);

	ret = packed_pt_import_from_buf(&pt, PARAM_BUF_PTR(in_str_params->G3), PARAM_BUF_LEN(in_str_params->G3), curve); EG(ret, err);
	ret = packed_pt_unpack(&win[3], &pt); EG(ret, err);

	ret = packed_pt_import_from_buf(&pt, PARAM_BUF_PTR(in_str_params->G4), PARAM_BUF_LEN(in_str_params->G4), curve); EG(ret, err);
	ret = packed_pt_unpack(&win[4], &pt); EG(ret, err);

	ret = packed_pt_import_from_buf(&pt, PARAM_BUF_PTR(in_str_params->G5), PARAM_BUF_LEN(in_str_params->G5), curve); EG(ret, err);
	ret = packed_pt_unpack(&win[5], &pt); EG(ret, err);

	ret = packed_pt_import_from_buf(&pt, PARAM_BUF_PTR(in_str_params->G6), PARAM_BUF_LEN(in_str_params->G6), curve); EG(ret, err);
	ret = packed_pt_unpack(&win[6], &pt); EG(ret, err);

	ret = packed_pt_import_from_buf(&pt, PARAM_BUF_PTR(in_str_params->G7), PARAM_BUF_LEN(in_str_params->G7), curve); EG(ret, err);
	ret = packed_pt_unpack(&win[7], &pt); EG(ret, err);

err:

	return ret;
}



int PRJ_WIN_MUL(prj_pt_t out, nn_src_t scalar, const ec_params *params)
{
    bitcnt_t scal_blen = 0;
   	bitcnt_t block_len = 0;
   	bitcnt_t w_idx = 0;
	nn seven;
	nn exp;
	nn w;
	word_t w_value;

    int ret, iszero;

	word_t blocks[(NN_MAX_BIT_LEN + 2) / 3] = {0};
    ret = nn_check_initialized(scalar); EG(ret, err);
	ret = ec_shortw_crv_check_initialized(&params->ec_curve); EG(ret, err);

	ret = prj_pt_init(out, &params->ec_curve); EG(ret, err);
	ret = prj_pt_zero(out); EG(ret, err);

	ret = nn_iszero(scalar, &iszero); EG(ret, err);

	/* Multiplication by zero is the point at infinity */
	if(iszero){
		goto err;
	}

    ret = nn_bitlen(scalar, &scal_blen); EG(ret, err);
    /* Sanity check */
    MUST_HAVE((scal_blen > 0), ret, err);
	block_len = (scal_blen + WIN_BITLEN - 1 ) / WIN_BITLEN;

	ret = nn_init(&seven, 0); EG(ret, err);
	ret = nn_set_word_value(&seven, WORD(7)); EG(ret, err);

	ret = nn_init(&exp, 0); EG(ret, err);
	ret = nn_copy(&exp, scalar); EG(ret, err);
    
	ret = nn_init(&w, 0); EG(ret, err);
	ret = nn_set_word_value(&w, WORD(0)); EG(ret, err);

	for (w_idx=0; w_idx< block_len; w_idx++) {
		ret = nn_and(&w, &exp, &seven); EG(ret, err);	
		blocks[w_idx] = w.val[0];
		ret = nn_rshift(&exp, &exp, 3); EG(ret, err);
	}

	for (w_idx = block_len; w_idx >0; w_idx--) {
		w_value = blocks[w_idx - 1];
		for (int _ = 0; _< 3; _++) {
			ret = prj_pt_dbl(out, out); EG(ret, err);
		}
		if (w_value != 0) {
			ret = prj_pt_add(out, out, &params->win[w_value]); EG(ret, err);
		}
	}
err:

	nn_uninit(&seven);
	nn_uninit(&w);
	nn_uninit(&exp);

    return ret;
}
