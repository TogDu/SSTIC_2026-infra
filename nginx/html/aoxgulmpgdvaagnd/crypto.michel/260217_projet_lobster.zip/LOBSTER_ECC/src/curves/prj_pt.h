/*
 *  Copyright (C) 2017 - This file is part of libecc project
 *
 *  Authors:
 *      Ryad BENADJILA <ryadbenadjila@gmail.com>
 *      Arnaud EBALARD <arnaud.ebalard@ssi.gouv.fr>
 *      Jean-Pierre FLORI <jean-pierre.flori@ssi.gouv.fr>
 *
 *  Contributors:
 *      Nicolas VIVET <nicolas.vivet@ssi.gouv.fr>
 *      Karim KHALFALLAH <karim.khalfallah@ssi.gouv.fr>
 *
 *  This software is licensed under a dual BSD and GPL v2 license.
 *  See LICENSE file at the root folder of the project.
 */
#ifndef __PRJ_PT_H__
#define __PRJ_PT_H__

#include "../nn/nn_mul.h"
#include "../fp/fp.h"
#include "../fp/fp_mul.h"
#include "../fp/fp_mul_redc1.h"
#include "ec_shortw.h"
#include "aff_pt.h"


typedef struct {
	fp X;
	fp Y;
	fp Z;
	ec_shortw_crv_src_t crv;
	word_t magic;
} prj_pt;

typedef prj_pt *prj_pt_t;
typedef const prj_pt *prj_pt_src_t;

typedef enum {
	PUBLIC_PT = 0,
	PRIVATE_PT = 1
} prj_pt_sensitivity;

#define WIN_BITLEN 3
#define WIN_LEN (1 << WIN_BITLEN)
typedef prj_pt win_t[WIN_LEN];




ATTRIBUTE_WARN_UNUSED_RET int prj_pt_check_initialized(prj_pt_src_t in);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_init(prj_pt_t in, ec_shortw_crv_src_t curve);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_init_from_coords(prj_pt_t in,
			    ec_shortw_crv_src_t curve,
			    fp_src_t xcoord,
			    fp_src_t ycoord, fp_src_t zcoord);
void prj_pt_uninit(prj_pt_t in);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_zero(prj_pt_t out);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_iszero(prj_pt_src_t in, int *iszero);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_is_on_curve(prj_pt_src_t in, int *on_curve);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_copy(prj_pt_t out, prj_pt_src_t in);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_to_aff(aff_pt_t out, prj_pt_src_t in);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_unique(prj_pt_t out, prj_pt_src_t in);
ATTRIBUTE_WARN_UNUSED_RET int ec_shortw_aff_to_prj(prj_pt_t out, aff_pt_src_t in);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_cmp(prj_pt_src_t in1, prj_pt_src_t in2, int *cmp);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_eq_or_opp(prj_pt_src_t in1, prj_pt_src_t in2, int *eq_or_opp);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_neg(prj_pt_t out, prj_pt_src_t in);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_add(prj_pt_t sum, prj_pt_src_t in1, prj_pt_src_t in2);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_dbl(prj_pt_t dbl, prj_pt_src_t in);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_mul(prj_pt_t out, nn_src_t m, prj_pt_src_t in);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_mul_blind(prj_pt_t out, nn_src_t m, prj_pt_src_t in);
/* XXX: WARNING: this function must only be used on public points! */
ATTRIBUTE_WARN_UNUSED_RET int _prj_pt_unprotected_mult(prj_pt_t out, nn_src_t cofactor, prj_pt_src_t public_in);
ATTRIBUTE_WARN_UNUSED_RET int check_prj_pt_order(prj_pt_src_t in_shortw, nn_src_t in_isorder, prj_pt_sensitivity s, int *check);

ATTRIBUTE_WARN_UNUSED_RET int prj_pt_import_from_prj_buf(prj_pt_t pt, const u8 *pt_buf, u16 pt_buf_len, ec_shortw_crv_src_t crv);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_import_from_aff_buf(prj_pt_t pt, const u8 *pt_buf, u16 pt_buf_len, ec_shortw_crv_src_t crv);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_import_from_packed_buf(prj_pt_t pt, const u8 *pt_buf, u16 pt_buf_len, ec_shortw_crv_src_t crv);

ATTRIBUTE_WARN_UNUSED_RET int prj_pt_export_to_prj_buf(prj_pt_src_t pt, u8 *pt_buf, u16 pt_buf_len);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_export_to_aff_buf(prj_pt_src_t pt, u8 *pt_buf, u16 pt_buf_len);
ATTRIBUTE_WARN_UNUSED_RET int prj_pt_export_to_packed_buf(prj_pt_src_t pt, u8 *pt_buf, u16 pt_buf_len);





 
ATTRIBUTE_WARN_UNUSED_RET int X_MUL(fp_t xR0, fp_t yR0, fp_src_t xP, fp_src_t yP, nn_src_t scalar, ec_shortw_crv_src_t curve);

ATTRIBUTE_WARN_UNUSED_RET int PRJ_XZ_ONLY_MUL(aff_pt_t R0, aff_pt_src_t P, nn_src_t scalar, ec_shortw_crv_src_t curve);

ATTRIBUTE_WARN_UNUSED_RET int AFF_POINT_ADD(aff_pt_t out, aff_pt_src_t in1, aff_pt_src_t in2);


#endif /* __PRJ_PT_H__ */
