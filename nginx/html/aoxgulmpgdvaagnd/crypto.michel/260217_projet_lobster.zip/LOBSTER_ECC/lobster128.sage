############################################## DEBUT: NE PAS MODIFIER ##############################################
# PoC de verification du programme lobster128.
# Pour le recalage crypto et les campagnes de tests poussés, il faut utiliser une version recente de sage (10.7).


import random
import hashlib
from sage.libs.pari import pari

p = 306200410558964958115439277392020245107

pub_key = [48663992601457699929525646427233013372, 1]

INFINITY=(0 ,1, 0)
K  = GF(p)

COMP_WIN = [ 
    INFINITY,
    (K(278768434721093841901521105876849179803), 1),
    (K(149970951362020540984345439090120070528), 0),
    (K(37926186415752960086399974152345432097),  1),
    (K(109271568165391603038898769195123467700), 1),
    (K(242326499217542250920684752291767422613), 1),
    (K(235179661673407420717511157008586352903), 0),
    (K(129854165200806121683078260483942315429), 0)]

hash_check = "d03db0d3bf2498f2d62eb8daf861f293"


def UNPACK(E, P):
    Q = E.lift_x(P[0])
    if int(Q[1])%2 != P[1]:
        Q = E(Q[0], int(-Q[1]))
    return Q


def UNPACK_WIN(E, COMP_WIN):
    WIN=[E(INFINITY)]
    for i in range(1, 8, 1):
        W = UNPACK(E, COMP_WIN[i])
        WIN.append(W)
    return WIN


def EXP_WIN(E, WIN, k):
    blocks=[]
    kk = int(k)
    while kk > 0:
        blocks.append(kk & 0b111)
        kk >>= 3
    if not blocks:
        return INFINITY
    
    Q = E(INFINITY)
    for w in reversed(blocks):
        for _ in range(3):
            Q = 2*Q
        if w !=0:
            Q = Q + WIN[w]
    if (Q==E(INFINITY)) :
        return INFINITY
    return (Q[0], Q[1])



def XZ_ADD(X1, Z1, X2, Z2, x, a, b, p): 
    X_out = -4*b*Z1*Z2 *(X1*Z2 + X2*Z1) + (X1*X2 - a*Z1*Z2)**2
    Z_out = x *  (X1*Z2 - X2*Z1)**2
    return (K(X_out), K(Z_out))


def XZ_DBL(X1, Z1, a, b, p):
    X_out = (X1**2 - a*Z1**2)**2 - 8*b*X1*Z1**3
    Z_out = 4*Z1*(X1**3 + a*X1*Z1**2 + b*Z1**3)
    return (K(X_out), K(Z_out))


def XZ_EXP(k, xP, yP, a, b, p):
    (X_R0, Z_R0) = (K(xP), K(1))
    (X_R1, Z_R1) = XZ_DBL(K(X_R0), K(Z_R0), a, b, p)
    kb=Integer(k)
    nb=kb.nbits()
    for i in reversed(range(nb-1)):
        bit=(kb>>i)&1
        if bit==0:
            (X_R1, Z_R1) = XZ_ADD(X_R0, Z_R0, X_R1, Z_R1, xP, a, b, p)
            (X_R0, Z_R0) = XZ_DBL(X_R0, Z_R0, a, b, p)  
        else:
            (X_R0, Z_R0) = XZ_ADD(X_R0, Z_R0, X_R1, Z_R1, xP, a, b, p)
            (X_R1, Z_R1) = XZ_DBL(X_R1, Z_R1, a, b, p)  
    xR0 = X_R0 * ((Z_R0)**(-1))     
    xR1 = X_R1 * ((Z_R1)**(-1))           
    # Marc Joye's formula : "Weierstass Elliptic Curves and Side-Channel Attacks"  (8)
    yR0 = (2*b + (a + xP * xR0) * (xP + xR0) - xR1 * (xP - xR0)**2) * (2 * (yP))**(-1) 
    return (xR0, yR0)    




# fonction utilitaire : inverse mod p (suppose p premier)
def inv_mod(x, p):
    x = x % p
    if x == 0:
        raise ZeroDivisionError("pas d'inverse pour 0 modulo p")
    # méthode fiable quand p est premier :
    return pow(x, p-2, p)


# addition de points P + Q sur y^2 = x^3 + a x + b (mod p)
def point_add(P, Q, a, p):
    if P is INFINITY:
        return Q
    if Q is INFINITY:
        return P
    x1, y1 = P
    x2, y2 = Q

    if (x1 - x2) % p == 0:
        # soit P = Q, soit P = -Q -> infini
        if (y1 + y2) % p == 0:
            return INFINITY   # P + (-P) = INFINITY
        # sinon ce sera le cas P == Q et y1 != -y2
    if x1 == x2 and y1 == y2:
        # doublage
        if y1 % p == 0:
            return INFINITY
        num = (3 * x1 * x1 + a) % p
        den = (2 * y1) % p
        lam = (num * inv_mod(den, p)) % p
    else:
        # addition de deux points distincts
        if (x2 - x1) % p == 0:
            return INFINITY
        num = (y2 - y1) % p
        den = (x2 - x1) % p
        lam = (num * inv_mod(den, p)) % p

    x3 = (lam * lam - x1 - x2) % p
    y3 = (lam * (x1 - x3) - y1) % p
    return (x3, y3)



def ECKCDSA_KEYGEN(E, WIN, p) :
    n = int(E.order())
    rnd  = randint(0, 2**p.nbits())
    while (rnd >= n) :
        rnd = randint(0, 2**p.nbits())   
    priv = mod(rnd, n)  
    k = mod(priv**(-1), n)
    pub = EXP_WIN(E, WIN, k) 
    return (priv, pub)

def ECKCDSA_SIGN(E, WIN, p, m, priv, pub) :
    with open(m, 'rb') as fobj:
        raw_m = fobj.read()
        n = int(E.order())
        s = 0
        while (s == 0):
            rnd = randint(0, 2**p.nbits())
            while (rnd >= n) :
                rnd = randint(0, 2**p.nbits())    
            
            k=mod(rnd, n)
            W = EXP_WIN(E, WIN, k)  
            hash=hashlib.sha256()
            hash.update(int(W[0]).to_bytes(16, byteorder="big"))
            r = int(hash.hexdigest()[0:32], 16)

            hash=hashlib.sha256()
            hash.update(int(pub[0]).to_bytes(16, byteorder="big"))
            hash.update(int(pub[1]).to_bytes(16, byteorder="big"))
            hash.update(raw_m)
            h = int(hash.hexdigest()[0:32], 16)
            
            e = mod(r.__xor__(h), n)
            s = mod(priv*(k-e) ,n)
        return (r,s)    

def ECKCDSA_VERIF(E, WIN, p, m, pub, sign):
    with open(m, 'rb') as fobj:
        raw_m = fobj.read()
        n = int(E.order())
        (r, s) = sign
        if (Integer(r).nbits() > E.order().nbits()):
            return False
        if (int(s) == 0):
            return False    
        if (int(s) >= n):
            return False

        # z = pub.X
        hash=hashlib.sha256()
        hash.update(int(pub[0]).to_bytes(16, byteorder="big"))
        hash.update(int(pub[1]).to_bytes(16, byteorder="big"))
        hash.update(raw_m)    
        h = int(hash.hexdigest()[0:32], 16) 
        e = mod(r.__xor__(h), n)
        
        print(f"------------ h = {hex(h)}")
        print(f"------------ r = {hex(r)}")
        print(f"------------ e = {hex(e)}")

        # S = e * P
        S = EXP_WIN(E, WIN, e)
        # X = s * Pub
        X = XZ_EXP(s, pub[0], pub[1], a, b, p)
        # W  = S + X
        W_aff = point_add(S, X, a, p)
        if (W_aff == INFINITY):
            return False
        # Check if r = H(W)
        hash=hashlib.sha256()
        hash.update(int(W_aff[0]).to_bytes(16, byteorder="big"))
        r_prime = int(hash.hexdigest()[0:32], 16)
        
        if (r_prime == r):
            return True
        return False
    return False



def LOBSTER128(pub_key, a, b, m, sign):
    hash=hashlib.sha256()
    hash.update(hex(a).encode())
    hash.update(hex(b).encode())

    if (hash.hexdigest()[0:32]!=hash_check):
        return False
        
    print("PARAM OK")
	
    E  = EllipticCurve(K, [a, b])
    n = order(E)
    WIN = UNPACK_WIN(E, COMP_WIN)
    
    return ECKCDSA_VERIF(E, WIN, p, m, pub_key, sign)



############################################## FIN : NE PAS MODIFIER ##############################################


a = ????,
b = ????,
m = b"!!!!!!! CHALL STTIC 2026 !!!!!!!"
sign = (????,, ????,)

E  = EllipticCurve(K, [a, b])
PUB = UNPACK(E, pub_key)

X_PUB = Integer(PUB[0])
Y_PUB = Integer(PUB[1])

pub=(K(X_PUB), K(Y_PUB))
print(f"X_PUB = {hex(X_PUB)} | Y_PUB = {hex(Y_PUB)}")

ret = LOBSTER128(pub, a, b, m, sign)
if (ret == True):
    print("CHALL DONE")
else :
    print("NOT YET")