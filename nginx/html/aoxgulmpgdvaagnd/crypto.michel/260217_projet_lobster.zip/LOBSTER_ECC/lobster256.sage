############################################## DEBUT: NE PAS MODIFIER ##############################################
# PoC du programme lobster256 pour recalage crypto.
# Pour des campagnes de tests poussés, il faut utiliser une version recente de sage (10.7).


import random
import hashlib
from sage.libs.pari import pari

p = 111559192104534069353760890008511275244926479951888026807753167566013787436761

#lobster_public_key.bin
pub_key = (70216273449864981114484960446726903050023072464427329312977511157887961422766, 1)

INFINITY=(0 ,1, 0)
K  = GF(p)

COMP_WIN = [ 
    INFINITY,
    (K(85085914869082369330525395072244563102593688729452879813198283169198884224575), 0),
    (K(28893242589823304197582809783987504479395934132007777783941484886546425616459), 1),
    (K(14480266976889616746879672282071694312587861308951520139374076899357498860534), 1),
    (K(99377351019195142121853048585682764164521365346999274120842633627341549890562), 1),
    (K(70309073374130670366598769873883012580292374537492061363624738933282846171635), 0),
    (K(97744160132098454288941487826589508807325216936773550403963117734958286628774), 1),
    (K(58616630683868570424357393152828184496438936995760647372506260183330814619273), 1)]

hash_check = "09c98a17fb28520efb09649c94842569"

def UNPACK(E, P):
    Q = E.lift_x(P[0])
    if int(Q[1])%2 != P[1]:
        Q = E(Q[0], int(-Q[1]))
    return Q


def UNPACK_WIN(E, COMP_WIN):
    WIN=[E(INFINITY)]
    for i in range(1, 8, 1):
        W = UNPACK(E, COMP_WIN[i])
        WIN.append(W)
    return WIN


def EXP_WIN(E, WIN, k):
    blocks=[]
    kk = int(k)
    while kk > 0:
        blocks.append(kk & 0b111)
        kk >>= 3
    if not blocks:
        return INFINITY
    
    Q = E(INFINITY)
    for w in reversed(blocks):
        for _ in range(3):
            Q = 2*Q
        if w !=0:
            Q = Q + WIN[w]
    if (Q==E(INFINITY)) :
        return INFINITY
    return (Q[0], Q[1])




def XZ_ADD(X1, Z1, X2, Z2, x, a, b, p): 
    X_out = -4*b*Z1*Z2 *(X1*Z2 + X2*Z1) + (X1*X2 - a*Z1*Z2)**2
    Z_out = x *  (X1*Z2 - X2*Z1)**2
    return (K(X_out), K(Z_out))


def XZ_DBL(X1, Z1, a, b, p):
    X_out = (X1**2 - a*Z1**2)**2 - 8*b*X1*Z1**3
    Z_out = 4*Z1*(X1**3 + a*X1*Z1**2 + b*Z1**3)
    return (K(X_out), K(Z_out))


def XZ_EXP(k, xP, yP, a, b, p):
    (X_R0, Z_R0) = (K(xP), K(1))
    (X_R1, Z_R1) = XZ_DBL(K(X_R0), K(Z_R0), a, b, p)
    kb=Integer(k)
    nb=kb.nbits()
    for i in reversed(range(nb-1)):
        bit=(kb>>i)&1
        if bit==0:
            (X_R1, Z_R1) = XZ_ADD(X_R0, Z_R0, X_R1, Z_R1, xP, a, b, p)
            (X_R0, Z_R0) = XZ_DBL(X_R0, Z_R0, a, b, p)  
        else:
            (X_R0, Z_R0) = XZ_ADD(X_R0, Z_R0, X_R1, Z_R1, xP, a, b, p)
            (X_R1, Z_R1) = XZ_DBL(X_R1, Z_R1, a, b, p)  
    xR0 = X_R0 * ((Z_R0)**(-1))     
    xR1 = X_R1 * ((Z_R1)**(-1))           
    # Marc Joye's formula : "Weierstass Elliptic Curves and Side-Channel Attacks"  (8)
    yR0 = (2*b + (a + xP * xR0) * (xP + xR0) - xR1 * (xP - xR0)**2) * (2 * (yP))**(-1) 
    print(f"--> (xR0, yR0) = ({hex(xR0)}, {hex(yR0)})")
    return (xR0, yR0)    




# fonction utilitaire : inverse mod p (suppose p premier)
def inv_mod(x, p):
    x = x % p
    if x == 0:
        raise ZeroDivisionError("pas d'inverse pour 0 modulo p")
    # méthode fiable quand p est premier :
    return pow(x, p-2, p)


############# __prj_pt_add_monty_no_cf

# addition de points P + Q sur y^2 = x^3 + a x + b (mod p)
def point_add(P, Q, a, p):
    if P is INFINITY:
        return Q
    if Q is INFINITY:
        return P
    x1, y1 = P
    x2, y2 = Q

    if (x1 - x2) % p == 0:
        # soit P = Q, soit P = -Q -> infini
        if (y1 + y2) % p == 0:
            return INFINITY   # P + (-P) = INFINITY
        # sinon ce sera le cas P == Q et y1 != -y2
    if x1 == x2 and y1 == y2:
        # doublage
        if y1 % p == 0:
            return INFINITY
        num = (3 * x1 * x1 + a) % p
        den = (2 * y1) % p
        lam = (num * inv_mod(den, p)) % p
    else:
        # addition de deux points distincts
        if (x2 - x1) % p == 0:
            return INFINITY
        num = (y2 - y1) % p
        den = (x2 - x1) % p
        lam = (num * inv_mod(den, p)) % p

    x3 = (lam * lam - x1 - x2) % p
    y3 = (lam * (x1 - x3) - y1) % p
    return (x3, y3)



def ECKCDSA_KEYGEN(E, WIN, p) :
    n = int(E.order())
    rnd  = randint(0, 2**p.nbits())
    while (rnd >= n) :
        rnd = randint(0, 2**p.nbits())   
    priv = mod(rnd, n)  
    k = mod(priv**(-1), n)
    pub = EXP_WIN(E, WIN, k) 
    return (priv, pub)

def ECKCDSA_SIGN(E, WIN, p, m, priv, pub) :
    with open(m, 'rb') as fobj:
        raw_m = fobj.read()
        n = int(E.order())
        s = 0
        while (s == 0):
            rnd = randint(0, 2**p.nbits())
            while (rnd >= n) :
                rnd = randint(0, 2**p.nbits())    
            
            k=mod(rnd, n)
            W = EXP_WIN(E, WIN, k)  
            hash=hashlib.sha256()
            hash.update(int(W[0]).to_bytes(32, byteorder="big"))
            r = int(hash.hexdigest(), 16)

            hash=hashlib.sha256()
            hash.update(int(pub[0]).to_bytes(32, byteorder="big"))
            hash.update(int(pub[1]).to_bytes(32, byteorder="big"))
            hash.update(raw_m)
            h = int(hash.hexdigest(), 16)
            e = mod(r.__xor__(h), n)

            print(f"------------ h = {hex(h)}")
            print(f"------------ r = {hex(r)}")
            print(f"------------ e = {hex(e)}")

            s = mod(priv*(k-e) ,n)
        return (r,s)    

def ECKCDSA_VERIF(E, WIN, p, m, pub, sign):
    with open(m, 'rb') as fobj:
        raw_m = fobj.read()
        n = int(E.order())
        (r, s) = sign
        if (Integer(r).nbits() > E.order().nbits()):
            return False
        if (int(s) == 0):
            return False    
        if (int(s) >= n):
            return False

        # z = pub.X
        hash=hashlib.sha256()
        hash.update(int(pub[0]).to_bytes(32, byteorder="big"))
        hash.update(int(pub[1]).to_bytes(32, byteorder="big"))
        hash.update(raw_m)    
        h = int(hash.hexdigest(), 16)
               
        e = mod(r.__xor__(h), n)
        
        print(f"------------ h = {hex(h)}")
        print(f"------------ r = {hex(r)}")
        print(f"------------ e = {hex(e)}")

        # S = e * P
        S = EXP_WIN(E, WIN, e)
        # X = s * Pub
        X = XZ_EXP(s, pub[0], pub[1], a, b, p)
        # W  = S + X
        W_aff = point_add(S, X, a, p)
        if (W_aff == INFINITY):
            return False
        # Check if r = H(W)
        hash=hashlib.sha256()
        hash.update(int(W_aff[0]).to_bytes(32, byteorder="big"))
        r_prime = int(hash.hexdigest(), 16)
        if (r_prime == r):
            return True
        return False
    return False

def LOBSTER256(pub_key, a, b, m, sign):
    hash=hashlib.sha256()
    hash.update(hex(a).encode())
    hash.update(hex(b).encode())

    if (hash.hexdigest()[0:32]!=hash_check):
        return False
    print("PARAM OK")
    
    E  = EllipticCurve(K, [a, b])
    n = order(E)
    WIN = UNPACK_WIN(E, COMP_WIN)

    return ECKCDSA_VERIF(E, WIN, p, m, pub_key, sign)

############################################## FIN : NE PAS MODIFIER ##############################################


a = ????,
b = ????,
m = b"!!!!!!! CHALL STTIC 2026 !!!!!!!"
sign = (????,, ????,)

E  = EllipticCurve(K, [a, b])
PUB = UNPACK(E, pub_key)

X_PUB = Integer(PUB[0])
Y_PUB = Integer(PUB[1])

pub=(K(X_PUB), K(Y_PUB))

ret = LOBSTER256(pub, a, b, m, sign)
if (ret == True):
    print("CHALL DONE")
else :
    print("NOT YET")