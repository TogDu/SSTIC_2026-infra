docker build -t diode_dst ./diode_dest/
docker build -t diode_src ./diode_src/

docker-compose.exe up
